# cs6210Project4
MapReduce Infrastructure

## Project Instructionss

[Project Description](description.md)

[Code walk through](structure.md)

### How to setup the project  
Same as project 3 instructions


## Implementation Details


